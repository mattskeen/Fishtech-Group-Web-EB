<?php
if (!defined('ABSPATH'))
	exit;
class DfdHeaderBuilder_LangSel extends DfdHeaderBuilderElementAbstract {

	protected $option_name = "show_lang_sel_header";
	protected $template = "lang_sel";

}
